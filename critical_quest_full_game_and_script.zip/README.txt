CRITICAL QUEST — FULL GAME + PRESENTATION SCRIPT

Open index.html.

This version includes:
- The full lesson script inside the playable game
- Eight levels, including the research library and final boss
- Professional IT, cybersecurity, media literacy, logic, and ethics scenarios
- Interactive questions and saved progress
- A built-in Presentation Mode containing a speaking script
- FTCC database research references

Controls:
- Arrow keys or A/D to move
- Enter near a gate
- On-screen controls work on mobile
